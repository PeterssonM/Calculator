﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {

        string input0 = "0";
        string input1 = "0";
        string whatOperation = string.Empty;
        string whatOperation_display = string.Empty;
        bool isOperatoractive = false;


        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        { }
        private void label1_Click(object sender, EventArgs e)
        { }
        private void label2_Click(object sender, EventArgs e)
        { }
        private void Form1_Load(object sender, EventArgs e)
        { }

        // 1,2,3,4,5,6,7,8,9,0,","
        private void Num_click(object sender, EventArgs e)
        {
            // Med objektet "button" lägger jag (senare) till den tryckta knappens värde i en variabel.
            Button button = (Button)sender;

            // Kollar om "," knappen var tryckt.
            if (button.Text == ",")
            {
                // Om "," finns i variabeln, kommer inte fler att läggas till.
                if (!input0.Contains(","))
                {
                    // Lägger till en 0:a i textboxen om den är tom när användaren trycker ",".
                    if (textBox1.Text == "")
                        textBox1.Text = "0";

                    textBox1.Text += button.Text;
                    input0 += button.Text;
                }
            }
            else
            {
                textBox1.Text += button.Text;
                input0 += button.Text;
            }

        }

        private void PlusMinus_click(object sender, EventArgs e)
        {
            // Togglar mellan att visa "-" och ingenting.
            if (label2.Text == "")
            {
                label2.Text = "-";
            }
            else
            {
                label2.Text = "";
            }

            // Byter tecken på den variabeln som knapptrycket hamnar framför.
            if (input1 != "0" && input0 == "")
            {
                input1 = Convert.ToString(double.Parse(input1) * (-1));
            }
            else
            {
                input0 = Convert.ToString(double.Parse(input0) * (-1));
            }
        }

        // +, -, *, /, √, 3√
        private void Operator_click(object sender, EventArgs e)
        {
            label2.Text = "";
            // Förhindrar att flera operatorer matas in direkt efter varandra.
            if (input0 != "")
            {
                Button button = (Button)sender;
                whatOperation_display = button.Text;

                // Lägger till en 0:a om en operator knapp trycks in före ett nummer då textrutan är tom, och om "whatOperation_display" INTE är = "√" eller = "3√".
                if (textBox1.Text == "" && whatOperation_display != "√" && whatOperation_display != "(3√)")
                    textBox1.Text = "0";

                // Förhindrar att "label1" visar ex. "9 |..." efter första beräkningen.
                if (isOperatoractive)
                {
                    // PerformCalculation_click körs om "isOperatoractive" är true.
                    button16.PerformClick();
                    input1 = textBox1.Text;
                    input0 = "";
                }
                whatOperation = button.Text;

                textBox1.Text += button.Text;

                input1 += input0;
                input0 = "";
                isOperatoractive = true;
            }
            
        }

        // =
        public void PerformCalculation_click(object sender, EventArgs e)
        {
            label2.Text = "";
            if (whatOperation_display != "√" && whatOperation_display != "(3√)")
                label1.Text += textBox1.Text + " | ";


            switch (whatOperation)
            {
                case "+":
                    // Förhindrar att programmet kraschar då alla variabler måste ha ett värde i rätt format (alltså bara siffror) för att programmet ska fungera.
                    if (input0 == "")
                        input0 = "0";
                    textBox1.Text = Convert.ToString(double.Parse(input1) + double.Parse(input0));
                    break;
                case "-":
                    if (input0 == "")
                        input0 = "0";
                    textBox1.Text = Convert.ToString(double.Parse(input1) - double.Parse(input0));
                    break;
                case "*":
                    if (input0 == "")
                        input0 = "1";
                    textBox1.Text = Convert.ToString(double.Parse(input1) * double.Parse(input0));
                    break;
                case "/":
                    if (input0 == "")
                        input0 = "1";
                    textBox1.Text = Convert.ToString(double.Parse(input1) / double.Parse(input0));
                    break;
                case "√":
                    // Om man har skrivit t.ex. "9√" kommer det att tolkas som "√9".
                    if (input1 != "0" && input0 == "")
                    {
                        textBox1.Text = Convert.ToString(Math.Pow(double.Parse(input1), 0.5));
                        // Genom att konvertera "input1" först till double och sedan tillbaka till string, försvinner de två 0:orna framför värdet på "input1". Testa med bara "input1" för att förstå. 
                        label1.Text += "√" + Convert.ToString(double.Parse(input1)) + " | ";
                    }

                    // Om man har skrivit t.ex. "9√9" kommer det att tolkas som "9*(√9)".
                    else if (input1 != "00")
                    {
                        textBox1.Text = Convert.ToString(double.Parse(input1) * (Math.Pow(double.Parse(input0), 0.5)));
                        label1.Text += Convert.ToString(double.Parse(input1)) + "(√" + Convert.ToString(double.Parse(input0)) + ")" + " | ";
                    }

                    // Om man har skrivit t.ex. "√9" kommer det att tolkas som "√9".
                    else
                    {
                        textBox1.Text = Convert.ToString(Math.Pow(double.Parse(input0), 0.5));
                        label1.Text += "√" + Convert.ToString(double.Parse(input0)) + " | ";
                    }

                    break;
                    case "(3√)":
                    if (input1 != "0" && input0 == "")
                    {
                        // Det är 15 decimaler eftersom att svaret då avrundas till närmsta heltal ex. 3√27 visar 3.
                        textBox1.Text = Convert.ToString(Math.Pow(double.Parse(input1), 0.333333333333333));
                        label1.Text += "(3√)" + Convert.ToString(double.Parse(input1)) + " | ";
                    }
                    else if (input1 != "00")
                    {
                        textBox1.Text = Convert.ToString(double.Parse(input1) * (Math.Pow(double.Parse(input0), 0.333333333333333)));
                        label1.Text += Convert.ToString(double.Parse(input1)) + "(3√" + Convert.ToString(double.Parse(input0)) + ")" + " | ";
                    }
                    else
                    {
                        textBox1.Text = Convert.ToString(Math.Pow(double.Parse(input0), 0.333333333333333));
                        label1.Text += "(3√)" + Convert.ToString(double.Parse(input0)) + " | ";
                    }

                    break;
                default:
                        break;
                }
            input1 = textBox1.Text;
            isOperatoractive = false;    
        }

        // C
        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            label1.Text = "";
            label2.Text = "";
            input0 = "0";
            input1 = "0";
            isOperatoractive = false;
            // Variabeln "whatOperation" behöver inte rensas eftersom att den skrivs över varje gång (rad: 98).
        }
    }
}